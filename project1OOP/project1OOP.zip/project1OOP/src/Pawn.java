public class Pawn extends ConcretePiece{
private Position PawnPosition;
private int numKils;

   public Pawn(Player owner, Position PawnPosition){
       super(owner,"♙");
     this.PawnPosition = PawnPosition;
       this.numKils = 0;
    }
    public Position getPawnPosition(){
       return this.PawnPosition;
    }

    public int getNumKils(){
       return this.numKils;
    }

}
